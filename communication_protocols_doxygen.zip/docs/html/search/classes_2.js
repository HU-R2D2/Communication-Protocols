var searchData=
[
  ['qik',['Qik',['../class_qik.html',1,'']]]
];
