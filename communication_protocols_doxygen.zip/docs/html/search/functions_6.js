var searchData=
[
  ['qik',['Qik',['../class_qik.html#a40dc67c7d28bb8e5148fa459795482b3',1,'Qik']]]
];
