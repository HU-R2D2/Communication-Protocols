var searchData=
[
  ['what',['what',['../class_connection_exception.html#a046e901d8e5fd6a893ae13640fab21bf',1,'ConnectionException']]]
];
