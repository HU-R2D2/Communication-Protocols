var searchData=
[
  ['connectionexception',['ConnectionException',['../class_connection_exception.html',1,'']]]
];
