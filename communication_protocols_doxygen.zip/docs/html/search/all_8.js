var searchData=
[
  ['send_5fmessage',['send_message',['../class_t_c_p_socket.html#ab3821e52ca9e792223d9dbc1c45f722f',1,'TCPSocket::send_message()'],['../class_t_c_p_socket.html#af9110e6f5eb1a535b0b1d4c4ddf20c85',1,'TCPSocket::send_message(uint8_t *d)']]],
  ['set_5fbrakes',['set_brakes',['../class_qik.html#a0c6762eb5ffe8eaaa12407126caf568c',1,'Qik']]],
  ['set_5flistener',['set_listener',['../class_t_c_p_socket.html#a074a08d48b3ec4e758f0d5fc287a32c2',1,'TCPSocket::set_listener()'],['../class_transport_protocol.html#ad7a9c131bbd9b2a26f1884b18ce11820',1,'TransportProtocol::set_listener()'],['../class_u_a_r_t.html#a865baf02a528c89bd5c0c2f01e04c2f1',1,'UART::set_listener()']]],
  ['set_5fm0_5fbrake',['set_m0_brake',['../class_qik.html#a2b2195033a0459df0daec4a01898811a',1,'Qik']]],
  ['set_5fm0_5fspeed',['set_m0_speed',['../class_qik.html#a6dc1b476ef343bdc6def0f6fd548002a',1,'Qik']]],
  ['set_5fm1_5fbrake',['set_m1_brake',['../class_qik.html#a1795a6acae6aa0f9be0784ff408e5225',1,'Qik']]],
  ['set_5fm1_5fspeed',['set_m1_speed',['../class_qik.html#a0973688f7c423dff7cfaa26dab91a126',1,'Qik']]],
  ['set_5freceive_5ftimeout',['set_receive_timeout',['../class_t_c_p_socket.html#a33138c2dbceb68dcc417e8c81ba35188',1,'TCPSocket']]],
  ['set_5fspeeds',['set_speeds',['../class_qik.html#a6d504c59e7eec46da40ad9e71199b6ff',1,'Qik']]],
  ['settransportprotocol',['setTransportProtocol',['../class_application_protocol.html#a6005c829686a0040803063aaea9d84ae',1,'ApplicationProtocol']]]
];
